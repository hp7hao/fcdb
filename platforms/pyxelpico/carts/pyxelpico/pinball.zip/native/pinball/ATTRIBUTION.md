# Pinball

**Original author**: Jay Kumogata
**License**: Apache-2.0
**Source**: https://github.com/jay-kumogata/RetroGames

## Changes for Pico8Go

- Resolution changed from 128x128 to 240x240 using screen-copy scaling (1.875x)
- Game renders at native 128x128, then scale-blits to fill 240x240 screen
- Input remapped for 8-button gamepad (A=left flipper, B=right flipper, A/Start=restart)
