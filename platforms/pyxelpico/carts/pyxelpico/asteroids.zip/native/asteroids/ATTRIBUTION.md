# Asteroids

**Original author**: Jay Kumogata
**License**: Apache-2.0
**Source**: https://github.com/jay-kumogata/RetroGames

## Changes for Pico8Go

- Resolution changed from 320x320 to 240x240
- Center offset changed from 160 to 120
- Wrap boundaries updated for smaller play area
- Initial rock positions scaled proportionally (0.75x)
- Input remapped for 8-button gamepad (A=shoot, Start/A=restart, D-pad=rotate)
