# Rolly

- Original title: Rolly
- Original authors: Davbo and Rory
- Original BBS thread: https://www.lexaloffle.com/bbs/?tid=31526
- Original cart: https://www.lexaloffle.com/bbs/cposts/5/54262.p8.png
- License: CC BY-NC-SA 4.0

## Port Notes

This PyxelPico port is a first-playable Python adaptation for the Pico8Go
handheld target. It preserves the documented core premise: jump, roll, hop,
and dive through sharp caves, recharge roll/hop from orbs, rescue friends, and
reach the exit.

The port uses a host-tested rules core and procedural replacement art/audio
rather than copying original sprites, music, exact level layout, precise
physics tuning, screen transitions, or full authored progression.

## Source Evidence

- FCDB entry: `id=54263`, `tid=31526`, author `Davbo`, license
  `CC4-BY-NC-SA`.
- BBS description: "Jump, Roll, Hop and Dive your way through sharp caves to
  rescue your friends."
- BBS thread/cart display: live cart `54262`, license `CC4-BY-NC-SA`.
- BBS comments mention spikes, rolling mid-air for boost, wall grab/jumps,
  breakable/bouncy walls, orbs that recharge hop/dash, deaths, and no save
  system.
- Local extraction: the live BBS cart downloads, but the current local cart
  extractor returns no useful Lua/API text for this image.
