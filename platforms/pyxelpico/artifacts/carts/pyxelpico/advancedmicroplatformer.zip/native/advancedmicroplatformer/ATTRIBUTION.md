# Advanced Micro Platformer - Starter Kit

- Original title: Advanced Micro Platformer - Starter Kit 1.1
- Original author: mhughson
- Original BBS thread: https://www.lexaloffle.com/bbs/?tid=28793
- Original cart: https://www.lexaloffle.com/bbs/cposts/3/37402.p8.png
- License: CC BY-NC-SA 4.0

## Port Notes

This PyxelPico port is a first-playable Python adaptation of the generic
platforming starter-kit mechanics for the Pico8Go handheld target. It presents
the starter kit as a small playable demo that highlights coyote jumps, buffered
jumps, variable jump height, sliding/friction, one-way platforms, camera
threshold scrolling, and a simple goal.

The port uses a host-tested rules core and procedural replacement art/audio
rather than copying original sprites, map data, animation system, camera shake,
or full tutorial code structure. The BBS thread also contains a separate Super
Mario Bros. cart; this port does not use that cart or any third-party branded
assets.

## Source Evidence

- FCDB entry: `id=37158`, `tid=28793`, author `mhughson`, license
  `CC4-BY-NC-SA`.
- BBS thread/cart display: live cart `37402`, license `CC4-BY-NC-SA`.
- BBS description states the author stripped Kid Bludd down into a platforming
  game starter kit and lists animation, collision, camera, forgiving jumps,
  sliding, friction, variable jump height, pass-through floors, and scrolling
  threshold features.
- Local extraction: FCDB's numeric cart URL is stale and the live starter-kit
  cart extracts no useful Lua/API text with current local tooling.
