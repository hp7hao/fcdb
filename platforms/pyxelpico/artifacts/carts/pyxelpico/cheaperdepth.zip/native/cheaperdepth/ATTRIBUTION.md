# CheaperDepth

**Original author**: Hiekichi
**License**: Unlicensed (no license file in original repository)
**Source**: https://github.com/Hiekichi/CheeperDepth

A depth charge naval game — drop charges from your ship to destroy submarines.

## Changes for Pico8Go

- Renamed entry point to cheaperdepth.py (catalog convention)
- Moved depth.pyxres to assets/ subdirectory
- Added relative path loading for resource file
- Added display_scale=3 for desktop development
