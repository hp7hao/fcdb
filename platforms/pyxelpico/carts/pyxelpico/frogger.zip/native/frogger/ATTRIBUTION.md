# Frogger

**Original author**: Jay Kumogata
**License**: Apache-2.0
**Source**: https://github.com/jay-kumogata/RetroGames

## Changes for Pico8Go

- Resolution changed from 208x240 to 240x240
- Added 5th goal slot to fill wider screen
- Frog start position re-centered for 240px width
- Input remapped for 8-button gamepad (D-pad movement)
