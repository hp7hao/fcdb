# Kanixian

**Original author**: Hiekichi
**License**: Unlicensed (no license file in original repository)
**Source**: https://github.com/Hiekichi/Kanixian

A Galaga-style space shooter with crab enemies and high score persistence.

## Changes for Pico8Go

- Renamed entry point to kanixian.py (catalog convention)
- Moved kani.pyxres and hiscore.txt to assets/ subdirectory
- Added relative path loading for resource file and high score file
- Added display_scale=3 for desktop development
