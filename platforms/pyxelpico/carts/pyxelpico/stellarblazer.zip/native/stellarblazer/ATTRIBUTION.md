# StellarBlazer

**Original author**: Hiekichi
**License**: Unlicensed (no license file in original repository)
**Source**: https://github.com/Hiekichi/StellarBlazer

A horizontal scrolling shooter — destroy radar, tank, and ICBM across 3 missions.

## Changes for Pico8Go

- Renamed entry point to stellarblazer.py (catalog convention)
- Moved sb.pyxres to assets/ subdirectory
- Added relative path loading for resource file
- Added display_scale=3 for desktop development
