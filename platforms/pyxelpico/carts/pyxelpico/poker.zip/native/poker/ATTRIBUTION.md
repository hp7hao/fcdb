# Poker

**Original author**: Hiekichi
**License**: Unlicensed (no license file in original repository)
**Source**: https://github.com/Hiekichi/Poker

A solo poker card game with hand evaluation and betting. Card art by Yotsuba (あひる小屋).

## Changes for Pico8Go

- Renamed entry point to poker.py (catalog convention)
- Moved card.pyxres and background images to assets/ subdirectory
- Added relative path loading for resource file and background images
- Added display_scale=3 for desktop development
