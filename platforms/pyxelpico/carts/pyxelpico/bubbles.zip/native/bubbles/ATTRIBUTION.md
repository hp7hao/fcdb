# Bubbles

**Original**: Bubbles by helpcomputer
**Source**: https://github.com/helpcomputer/bubbles
**License**: MIT (2022, helpcomputer)
**Adapted**: Resolution centered for 240x240 Pico8Go display, input remapped for 8-button controller
