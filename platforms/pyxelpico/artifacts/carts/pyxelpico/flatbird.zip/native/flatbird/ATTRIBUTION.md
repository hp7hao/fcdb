# FlatBird

**Original author**: Hiekichi
**License**: Unlicensed (no license file in original repository)
**Source**: https://github.com/Hiekichi/FlatBird

A Flappy Bird clone — tap to jump through pipe gaps.

## Changes for Pico8Go

- Renamed entry point to flatbird.py (catalog convention)
- Moved flatbirdgame.pyxres to assets/ subdirectory
- Added relative path loading for resource file
- Added display_scale=3 for desktop development
