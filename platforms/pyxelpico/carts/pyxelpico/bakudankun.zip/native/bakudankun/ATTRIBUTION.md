# BakudanKun

**Original author**: Hiekichi
**License**: Unlicensed (no license file in original repository)
**Source**: https://github.com/Hiekichi/BakudanKunPy

A Bomberman-style action game with 6 stages and 4 enemy types.

## Changes for Pico8Go

- Renamed entry point to bakudankun.py (catalog convention)
- Moved bomb.pyxres to assets/ subdirectory
- Added relative path loading for resource file
- Added display_scale=3 for desktop development
