# ChottoCopter

**Original author**: Hiekichi
**License**: Unlicensed (no license file in original repository)
**Source**: https://github.com/Hiekichi/ChottoCopter

A Choplifter-style helicopter rescue game — rescue 56 hostages from cabins and return them to base. Features tanks, fighter jets, and a UFO as enemies.

## Changes for Pico8Go

- Renamed entry point to chottocopter.py (catalog convention)
- Moved copter.pyxres to assets/ subdirectory
- Added relative path loading for resource file
- Added display_scale=3 for desktop development
