# 8 Legs to Love

- Original title: 8 Legs to Love
- Original author: bridgs
- Original BBS thread: https://www.lexaloffle.com/bbs/?tid=29451
- Original cart: https://www.lexaloffle.com/bbs/cposts/4/41422.p8.png
- License: CC BY-NC-SA 4.0

## Port Notes

This PyxelPico port is a first-playable Python adaptation for the Pico8Go
handheld target. It preserves the documented core premise: move a spider,
spin and place web strands, catch bugs for points, and progress through timed
levels. Beetles damage web strands and butterflies are rare high-value catches.

The port uses a host-tested rules core and procedural replacement art/audio
rather than copying original sprites, maps, music, exact bug patterns, level
timing, or web-physics tuning from the PICO-8 cart.

## Source Evidence

- FCDB entry: `id=41423`, `tid=29451`, author `bridgs`, license
  `CC4-BY-NC-SA`.
- BBS description: "Spin a web, eat bugs, earn points, and have fun!"
- BBS controls: arrows move, hold Z to spin web, then tap Z to place web.
- BBS gameplay notes: six timed levels, web building, beetles chew through
  webs for 30 points, and rare rainbow butterflies are worth 100 points.
- Local extraction: the live BBS cart downloads, but the current local cart
  extractor does not expose useful Lua/API text for this image.
